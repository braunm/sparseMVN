library(testthat)
library(sparseMVN)

test_check("sparseMVN")
